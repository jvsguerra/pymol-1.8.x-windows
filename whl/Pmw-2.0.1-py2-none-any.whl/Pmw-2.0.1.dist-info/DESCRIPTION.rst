Pmw is a toolkit for building high-level compound widgets, or megawidgets,
constructed using other widgets as component parts. It promotes consistent look and feel within
 and between graphical applications, is highly configurable to your needs and is easy to use.

